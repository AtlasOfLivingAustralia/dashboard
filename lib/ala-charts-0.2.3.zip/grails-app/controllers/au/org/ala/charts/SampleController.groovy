package au.org.ala.charts

class SampleController {

    def index() { }

    def tree() {}
}
