// resource bundles
modules = {

    charts {
        resource url: '/js/charts2.js'
        resource url: '/js/jquery.jstree.js'
    }

}
